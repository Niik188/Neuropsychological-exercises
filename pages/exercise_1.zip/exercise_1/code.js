//Обьекты из html
const left_button = document.getElementById("left-button")
const right_button = document.getElementById("right-button")
const top_button = document.getElementById("top-button")
const bottom_button = document.getElementById("bottom-button")
const rotate_button = document.getElementById("rotate-button")
const cube1 = document.querySelector('.cube1');
const cube1_id = document.getElementById('cube1_id');
const cube1_article = document.querySelector('.cube1 > article');
const cube2 = document.querySelector('.cube2');
const cube3 = document.querySelector('.cube3');
const cube4 = document.querySelector('.cube4');
const cube5 = document.querySelector('.cube5');
const cube6 = document.querySelector('.cube6');

//переменные
var selection = 0
var rotateY = 0 
var rotateX = 0
var rotateZ = 0 

function selectEdge(){
    //При нажатии клавиш
    window.addEventListener('keydown', (e)=>{
    //Проверка, что мы выбрали кубик
    if (selection != 0) { 
        if (e.key == "ArrowLeft") {
            rotateY+=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }

        if (e.key == "ArrowRight") {
            rotateY-=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }

        if (e.key == "ArrowUp") {
            rotateX-=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }

        if (e.key == "ArrowDown") {
            rotateX+=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }
    }
    console.log(rotateX)
    console.log(rotateY)  
    })

    //При нажатии 1-го кубика
    cube1.addEventListener('click', ()=>{
        selection = 1
        rotateX = 0
        rotateY = 0
        cube1_article.style.backgroundColor = 'green'
        document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
    })

    //При нажатии 2-го кубика
    cube2.addEventListener('click', ()=>{
        selection = 2
        rotateX = 0
        rotateY = 0
        cube1_article.style.backgroundColor = 'green'
        document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
    })

    //При нажатии 3-го кубика
    cube3.addEventListener('click', ()=>{
        selection = 3
        rotateX = 0
        rotateY = 0
        cube1_article.style.backgroundColor = 'green'
        document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
    })

    //При нажатии 4-го кубика
    cube4.addEventListener('click', ()=>{
        selection = 4
        rotateX = 0
        rotateY = 0
        cube1_article.style.backgroundColor = 'green'
        document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
    })

    //При нажатии 5-го кубика
    cube5.addEventListener('click', ()=>{
        selection = 5
        rotateX = 0
        rotateY = 0
        cube1_article.style.backgroundColor = 'green'
        document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
    })

    //При нажатии 6-го кубика
    cube6.addEventListener('click', ()=>{
        selection = 6
        rotateX = 0
        rotateY = 0
        cube1_article.style.backgroundColor = 'green'
        document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
    })
    
    //При нажатии на кнопку вправо
    right_button.addEventListener('click', (e)=>{
        if (selection != 0) {
            if (rotateX == 0||rotateX == 180||rotateX == 360||rotateX == -180||rotateX == -360) { 
                rotateY+=90
                document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
            }else{
                rotateZ+=90 
                document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg rotateZ(${rotateZ}deg)` ;
            }
            
            if (rotateY > 360) {
                rotateY = -90
            }

            if (rotateZ > 360) {
                rotateZ = -90
            }
        console.log(rotateY)
        console.log(rotateZ) 
        }
        
    })

    //При нажатии на кнопку влево
    left_button.addEventListener('click', (e)=>{
        if (selection != 0) { 
            rotateY-=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }
        if (rotateY < -360) {
            rotateY = 90
        }
        console.log(rotateY) 
    })

    //При нажатии на кнопку вниз
    bottom_button.addEventListener('click', (e)=>{
        if (selection != 0) { 
            rotateX-=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }
        if (rotateX < -360) {
            rotateX = 90
        }
        console.log(rotateX) 
    })

    //При нажатии на кнопку вверх
    top_button.addEventListener('click', (e)=>{
        if (selection != 0) { 
            rotateX+=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)` ;
        }
        if (rotateX > 360) {
            rotateX = -90
        }
        console.log(rotateX)
    })

    //При нажатии на кнопку вращения
    rotate_button.addEventListener('click', (e)=>{
        if (selection != 0) { 
            rotateZ+=90
            document.querySelector(`.cube${selection}`).style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) rotateZ(${rotateZ}deg)` ;
        }
        if (rotateZ > 360) {
            rotateZ = -90
        }
        console.log(rotateZ)
    })
    // document.querySelectorAll('nav a').forEach(elem => {
    //     elem.addEventListener('click', (e) => {
    //         e.preventDefault();
    //         let edgeName = e.target.hash.replace(/#/, '');
    //         cube.style.transform = 'perspective(700px) rotateX('+degs[edgeName].X+'deg) rotateY('+degs[edgeName].Y+'deg)';
    //     })
    // });
}

//После загрузки сайта
document.addEventListener('DOMContentLoaded', () => {
    selectEdge();
});